<?

session_start();

@ $status = $_GET["status"];
@ $campo = $_SESSION['campo'];

if ( $status == 'resultado' ) {

if ( isset($campo) ) {
$tmp = array_keys($campo);
$indice = end($tmp);
$indice ++;
}
else {
$indice = 0;
}

$campo[$indice]['id'] = $indice;
$campo[$indice]['titulo'] = $titulo = $_POST["titulo"];
$campo[$indice]['maxlenght'] = $_POST["maxlength"];
$campo[$indice]['size'] = $_POST["size"];
$campo[$indice]['obrigatorio'] = $_POST["obrigatorio"];
$campo[$indice]['tipo'] = $_POST["tipo"];
$campo[$indice]['tam_min'] = $_POST["tam_min"];
$campo[$indice]['tam_max'] = $_POST["tam_max"];

$_SESSION['campo'] = $campo;

} // FECHA IF DO STATUS = RESULTADO

# print_r($campo);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: MaCaFe Webdeveloper :: Gerador de Formul�rio ::</title>

<link href="estilos/estilos.css" rel="stylesheet" type="text/css" />

<script language="javascript">

<!--
function checa_form(form){

if (form.titulo.value == ""){
alert("Aten��o: O campo t�tulo deve ser preenchido");
form.titulo.focus();
return (false);
}

if (form.maxlength.value == ""){
alert("Aten��o: O campo max length deve ser preenchido");
form.maxlength.focus();
return (false);
}

if (form.size.value == ""){
alert("Aten��o: O campo size deve ser preenchido");
form.size.focus();
return (false);
}

if (form.obrigatorio.value == ""){
alert("Aten��o: O campo obrigat�rio deve ser selecionado");
form.obrigatorio.focus();
return (false);
}

if (form.tipo.value == ""){
alert("Aten��o: O campo tipo deve ser selecionado");
form.tipo.focus();
return (false);
}

return (true);
}
//-->

</script>

</head>

<body>

<table width="560" height="20" cellpadding="0" cellspacing="0" border="1" bordercolor="#cccccc" bgcolor="#F4F4F4">

<?

if ( $status == 'apagar') {
$id = $_GET["id"];

echo '
<tr>
  <td bgcolor="#CCCCCC" align="left">
  &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Resultado</b></font>
  </td>
</tr>
<tr>
  <td align="left">
   <table width="560" cellpadding="5">
         <tr>
           <td align="left">
           &nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp;Voc� tem certeza que deseja apagar o campo '.$campo[$id]["titulo"].' ?<br />
           &nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp; <a href="?status=apagar_conf&id='.$id.'&titulo='.$campo[$id]["titulo"].'" title"Sim(Confirmar)">Sim</a> - <a href="passo2.php" title"N�o(Cancelar)">N�o</a>
           </td>
         </tr>
   </table>
  </td>
</tr>
 ';
}

if ( $status == 'apagar_conf') {
$id = $_GET["id"];
$titulo = $_GET["titulo"];

unset($_SESSION['campo'][$id]);

echo '
<tr>
  <td bgcolor="#CCCCCC" align="left">
  &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Resultado</b></font>
  </td>
</tr>
<tr>
  <td align="left">
   <table width="560" cellpadding="5">
         <tr>
           <td align="left">
           &nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp;Campo '.$titulo.' apagado com sucesso ?<br />
           </td>
         </tr>
   </table>
  </td>
</tr>
 ';
}

if ( $status == 'editar') {
$id = $_GET["id"];

echo '
<tr>
  <td bgcolor="#CCCCCC" align="left">
  &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Editando dados</b></font>
  </td>
</tr>
<tr>
    <td>
         <form onsubmit="return checa_form(this)" name="form" action="?status=editar_resultado&id='.$id.'" method="post">
        <table width="560" >
<tr>
           <td align="left">
                   &nbsp;<img src="imagens/seta7.gif" >&nbsp;T�tulo&nbsp;:
                   </td>
                   <td align="left">
                                  <input name="titulo" type="text" value="'.$campo[$id]["titulo"].'" size="60" maxlength="100"  />
                            </td>
</tr>
<tr>
           <td align="left">
                   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Max length&nbsp;:
                   </td>
                   <td align="left">
                   <input name="maxlength" type="text" value="'.$campo[$id]["maxlenght"].'" size="5" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagens/seta7.gif" >&nbsp;Size :&nbsp;<input name="size" type="text" value="'.$campo[$id]["size"].'" size="5" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagens/seta7.gif" >&nbsp;Obrig�torio&nbsp;:&nbsp;&nbsp;
<select name="obrigatorio" >
<option value=""></option>
<option value="N�o" '; if ( $campo[$id]["obrigatorio"] == 'N�o' ) { echo 'selected'; } echo '>N�o</option>
<option value="Sim" '; if ( $campo[$id]["obrigatorio"] == 'Sim' ) { echo 'selected'; } echo '>Sim</option>
</select>
                   </td>
</tr>
<tr>
           <td align="left">
                   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Tipo&nbsp;:
                   </td>
                   <td align="left">
<select name="tipo" >
<option value=""></option>
<option value="CPF" '; if ( $campo[$id]["tipo"] == 'CPF' ) { echo 'selected'; } echo '>CPF</option>
<option value="CNPJ" '; if ( $campo[$id]["tipo"] == 'CNPJ' ) { echo 'selected'; } echo '>CNPJ</option>
<option value="Email" '; if ( $campo[$id]["tipo"] == 'Email' ) { echo 'selected'; } echo '>Email</option>
<option value="N�meros" '; if ( $campo[$id]["tipo"] == 'N�meros' ) { echo 'selected'; } echo '>N�meros</option>
<option value="Texto" '; if ( $campo[$id]["tipo"] == 'Texto' ) { echo 'selected'; } echo '>Texto</option>
<option value="Valor" '; if ( $campo[$id]["tipo"] == 'Valor' ) { echo 'selected'; } echo '>Valor</option>
</select>&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagens/seta7.gif" >&nbsp;Tam. m�n.&nbsp;:&nbsp;&nbsp;<input name="tam_min" type="text" value="'.$campo[$id]["tam_min"].'" size="3" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" />&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagens/seta7.gif" >&nbsp;Tam. m�x.&nbsp;:&nbsp;&nbsp;<input name="tam_max" type="text" value="'.$campo[$id]["tam_max"].'" size="3" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" />
                   </td>
</tr>
       </table>
           <table>
         <tr>
         <td align="center" width="550">
         <input name="Editar campo" type="submit" value="Editar campo" />
         </td>
         </tr></form>
                  </table>
        </td>
 </tr>
 ';

}

if ( $status == 'editar_resultado') {
$indice = $id = $_GET["id"];

$campo[$indice]['id'] = $indice;
$campo[$indice]['titulo'] = $titulo = $_POST["titulo"];
$campo[$indice]['maxlenght'] = $_POST["maxlength"];
$campo[$indice]['size'] = $_POST["size"];
$campo[$indice]['obrigatorio'] = $_POST["obrigatorio"];
$campo[$indice]['tipo'] = $_POST["tipo"];
$campo[$indice]['tam_min'] = $_POST["tam_min"];
$campo[$indice]['tam_max'] = $_POST["tam_max"];

$_SESSION['campo'] = $campo;

echo '
<tr>
  <td bgcolor="#CCCCCC" align="left">
  &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Resultado</b></font>
  </td>
</tr>
<tr>
  <td align="left">
   <table width="560" cellpadding="5">
         <tr>
           <td align="left">
           &nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp;Campo alterado com sucesso<br />
           </td>
         </tr>
   </table>
  </td>
</tr>
 ';
}

?>

<tr>
  <td bgcolor="#CCCCCC" align="left">
  &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Determinando dados</b></font>
  </td>
</tr>
<tr>
    <td>
         <form onsubmit="return checa_form(this)" name="form" action="?status=resultado" method="post">
        <table width="560" >
<tr>
           <td align="left">
                   &nbsp;<img src="imagens/seta7.gif" >&nbsp;T�tulo&nbsp;:
                   </td>
                   <td align="left">
                                  <input name="titulo" type="text" value="" size="60" maxlength="100"  />
                            </td>
</tr>
<tr>
           <td align="left">
                   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Max length&nbsp;:
                   </td>
                   <td align="left">
                   <input name="maxlength" type="text" value="" size="5" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagens/seta7.gif" >&nbsp;Size :&nbsp;<input name="size" type="text" value="" size="5" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagens/seta7.gif" >&nbsp;Obrig�torio&nbsp;:&nbsp;&nbsp;
<select name="obrigatorio" >
<option value=""></option>
<option value="N�o">N�o</option>
<option value="Sim">Sim</option>
</select>
                   </td>
</tr>
<tr>
           <td align="left">
                   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Tipo&nbsp;:
                   </td>
                   <td align="left">
<select name="tipo" >
<option value=""></option>
<option value="CPF">CPF</option>
<option value="CNPJ">CNPJ</option>
<option value="Email">Email</option>
<option value="N�meros">N�meros</option>
<option value="Texto">Texto</option>
<option value="Valor">Valor</option>
</select>&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagens/seta7.gif" >&nbsp;Tam. m�n.&nbsp;:&nbsp;&nbsp;<input name="tam_min" type="text" value="" size="3" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" />&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagens/seta7.gif" >&nbsp;Tam. m�x.&nbsp;:&nbsp;&nbsp;<input name="tam_max" type="text" value="" size="3" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" />
                   </td>
</tr>
       </table>
           <table>
         <tr>
         <td align="center" width="550">
         <input name="Adicionar campo" type="submit" value="Adicionar campo" />
         </td>
         </tr></form>
                  </table>
        </td>
 </tr>

<tr>
  <td bgcolor="#CCCCCC" align="left">
  &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Campos existentes</b></font>
  </td>
</tr>
<tr>
    <td>
        <table>
         <tr>
         <td align="center" width="550">
              <!-- asdasdddddddddddddddddddddddddd -->

                <?php
                
if(count( $campo) > 0) {

                //exibe campo titulo dos campos
                echo '<table width="550" height="23" bgcolor="#ffffff">';
                echo '<tr>
<td width="25" height="23" bgcolor="#E3E3E3" align="center"><img src="imagens/bt_editar.png" /></td>
<td width="25" height="23" bgcolor="#E3E3E3" align="center"><img src="imagens/apagar.png" /></td>
<td width="425" height="23" bgcolor="#E3E3E3" align="center"><strong><font color="#666666" size="1">&nbsp;T�tulo&nbsp;</font></td>
<td width="30" height="23" bgcolor="#E3E3E3"><strong><font color="#666666" size="1">&nbsp;Max&nbsp;length&nbsp;</font></strong></td>
<td width="30" height="23" bgcolor="#E3E3E3"><strong><font color="#666666" size="1">&nbsp;Size&nbsp;</font></strong></td>
<td width="30" height="23" bgcolor="#E3E3E3"><strong><font color="#666666" size="1">&nbsp;Obrig�torio&nbsp;</font></strong></td>
<td width="30" height="23" bgcolor="#E3E3E3"><strong><font color="#666666" size="1">&nbsp;Tipo&nbsp;</font></strong></td>
<td width="30" height="23" bgcolor="#E3E3E3"><strong><font color="#666666" size="1">&nbsp;T.&nbsp;m�n&nbsp;</font></strong></td>
<td width="30" height="23" bgcolor="#E3E3E3"><strong><font color="#666666" size="1">&nbsp;T.&nbsp;m�x&nbsp;</font></strong></td>
</tr>';
                Foreach($_SESSION['campo'] as $valor){
                    echo "<tr>";

                    Foreach($valor as $key=>$valor2){
                        If($key == 'id'){
                        
          if ( ( $valor2 % 2 ) == 1 ) { $fundo = '#F2F2F2'; }	else { $fundo = '#F8F8F8'; }

                           echo '
<td width="25" height="23" bgcolor="'.$fundo.'"><a href="?status=editar&id='.$valor2.'" title="Editar"><img src="imagens/bt_editar.png" border="0" /></a></td>
<td width="25" height="23" bgcolor="'.$fundo.'"><a href="?status=apagar&id='.$valor2.'" title="Apagar"><img src="imagens/apagar.png" border="0" /></a></td>
                    ';
                         }
                        
                        If($key == 'titulo'){
                           echo '<td width="400" height="23" bgcolor="'.$fundo.'"><font color="#666666" size="1">&nbsp;'.$valor2.'&nbsp;</font></td>';
                        }
                        
                        If($key == 'maxlenght'){
                           echo '<td width="30" height="23" bgcolor="'.$fundo.'"><font color="#666666" size="1">&nbsp;'.$valor2.'&nbsp;</font></td>';
                        }
                        If($key == 'size'){
                           echo '<td width="30" height="23" bgcolor="'.$fundo.'"><font color="#666666" size="1">&nbsp;'.$valor2.'&nbsp;</font></td>';
                        }
                        If($key == 'obrigatorio'){
                           echo '<td width="30" height="23" bgcolor="'.$fundo.'"><font color="#666666" size="1">&nbsp;'.$valor2.'&nbsp;</font></td>';
                        }
                        If($key == 'tipo'){
                           echo '<td width="30" height="23" bgcolor="'.$fundo.'"><font color="#666666" size="1">&nbsp;'.$valor2.'&nbsp;</font></td>';
                        }
                        If($key == 'tam_min'){
                           echo '<td width="30" height="23" bgcolor="'.$fundo.'"><font color="#666666" size="1">&nbsp;'.$valor2.'&nbsp;</font></td>';
                        }
                        If($key == 'tam_max'){
                           echo '<td width="30" height="23" bgcolor="'.$fundo.'"><font color="#666666" size="1">&nbsp;'.$valor2.'&nbsp;</font></td>';
                        }
                    }
                    echo "</tr>";
                }
                echo "</table>";
                }//FECHA IF(count)
else {
echo 'N�o existe nenhum campo cadastrado.';
}
              ?>

              <!-- asdasdddddddddddddddddddddddddd -->
         </td>
         </tr>
        </table>

           <table>
         <tr>
         <td align="center" width="550">
         <button onClick="javascript:window.location.href='passo1.php'"><< Anterior</button>&nbsp;<button onClick="javascript:window.location.href='passo3.php'">Pr�ximo >></button>
         </td>
         </tr>
                  </table>
     </td>
 </tr>
</table>

</body>
</html>
