<?

session_start();

@ $campo = $_SESSION['campo'];

echo '
<!--
Formul�rio com valida��o em JavaScript e PHP Gerado por MaCaFe Script Creator
Todos direitos intelectuais de cria��o e desenvolvimento para Felipe Cardoso Martins
Email: felipe@eletronicparty.com - Site oficial: www.eletronicparty.com/felipe
-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: MaCaFe Webdeveloper :: Gerador de Formul�rio ::</title>

<script language="javascript" src=\'classes/classes_js.js\'></script>

</head>

<body>
';

error_reporting(E_ALL);
require ('classes/classes_php.php');

if ( isset($_GET["status"]) ) {
$status = $_GET["status"];
}
else {
$status = NULL;
}

if ( $status == 'resultado' ) {

$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i];
${'campo'.$indice.''} = $_POST["campo$indice"];
;

}

$erro = 0 ;

$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;

if ( $campo[$indice]["obrigatorio"] == 'Sim' ) {
if ( empty( ${'campo'.$indice.''} ) ){
echo 'Aten��o: O campo '.$campo[$indice]["titulo"].' deve ser preenchido.<br />';
$erro ++;
}
}

if ( ( $campo[$indice]["tam_min"] != '' ) or ( !empty($campo[$indice]["tam_min"]) ) ) {
if ( ( strlen(${'campo'.$indice.''}) < $campo[$indice]["tam_min"] ) and ( !empty(${'campo'.$indice.''}) ) ){
echo 'Aten��o: O campo '.$campo[$indice]["titulo"].' deve ter no m�nimo '.$campo[$indice]["tam_min"].' caracteres.<br />';
$erro ++;
}
}

if ( ( $campo[$indice]["tam_max"] != '' ) or ( !empty($campo[$indice]["tam_max"]) ) ) {
if ( ( strlen(${'campo'.$indice.''}) > $campo[$indice]["tam_max"] ) and ( !empty(${'campo'.$indice.''}) ) ){
echo 'Aten��o: O campo '.$campo[$indice]["titulo"].' deve ter no m�ximo '.$campo[$indice]["tam_max"].' caracteres.<br />';
$erro ++;
}
}

if ( ( $campo[$indice]["tipo"] == 'CPF' )  ) {
 if ( !empty (${'campo'.$indice.''}) ) {
 $oCpf = new cpf;
 if ($oCpf->verifica_cpf(${'campo'.$indice.''})){
 # Passo com sucesso o cpf
 }
 else{
 echo 'Aten��o: O '.$campo[$indice]["titulo"].' ( '.${'campo'.$indice.''}.' ) &eacute; inv&aacute;lido.<BR>';
 $erro ++;
 }
}
}

if ( ( $campo[$indice]["tipo"] == 'Email' )  ) {
if ( !empty (${'campo'.$indice.''}) ) {
  if (verifica_email(${'campo'.$indice.''})){
# Passo com sucesso o email
 }
 else{
 echo 'Aten��o: O '.$campo[$indice]["titulo"].' ( '.${'campo'.$indice.''}.' ) &eacute; inv&aacute;lido.<BR>';
 $erro ++;
 }
}
}

if ( ( $campo[$indice]["tipo"] == 'CNPJ' )  ) {
if ( !empty (${'campo'.$indice.''}) ) {
$cnpj= ${'campo'.$indice.''};
$oCnpj = new cnpj;
if ($oCnpj->verfica_cnpj($cnpj)==1){
# Passo com sucesso o cnpj
}
else{
echo 'Aten��o: O '.$campo[$indice]["titulo"].' ( '.${'campo'.$indice.''}.' ) &eacute; inv&aacute;lido.<BR>';
$erro ++;
 }
}
}

}    // fecha for do loop

if ( $erro != 0 ) {
echo '<a href="javascript:history.go(-1);" title="Voltar">Voltar</a>';
}

else {

$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;
echo ''.$campo[$indice]["titulo"].' = '.${'campo'.$indice.''}.' <br />
';
}

}    // fecha else do if != 0
}    // fecha id do resultado

echo '
<script language="javascript">
<!--
function valida_'.$_SESSION['form_name'].'('.$_SESSION['form_name'].'){
';

$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;

if ( $campo[$indice]["obrigatorio"] == 'Sim' ) {
echo '
if ('.$_SESSION['form_name'].'.campo'.$indice.'.value == ""){
alert("Aten��o: O campo '.$campo[$indice]["titulo"].' deve ser preenchido");
'.$_SESSION['form_name'].'.campo'.$indice.'.focus();
return (false);
}
';
}

if ( ( $campo[$indice]["tam_min"] != '' ) or ( !empty($campo[$indice]["tam_min"]) ) ) {
echo '
if ('.$_SESSION['form_name'].'.campo'.$indice.'.value.length < '.$campo[$indice]["tam_min"].' ){
alert("Aten��o: O campo '.$campo[$indice]["titulo"].' deve ter no m�nimo '.$campo[$indice]["tam_min"].' caracteres");
'.$_SESSION['form_name'].'.campo'.$indice.'.focus();
return (false);
}
';
}

if ( ( $campo[$indice]["tam_max"] != '' ) or ( !empty($campo[$indice]["tam_max"]) ) ) {
echo '
if ('.$_SESSION['form_name'].'.campo'.$indice.'.value.length > '.$campo[$indice]["tam_max"].' ){
alert("Aten��o: O campo '.$campo[$indice]["titulo"].' deve ter no m�ximo '.$campo[$indice]["tam_max"].' caracteres");
'.$_SESSION['form_name'].'.campo'.$indice.'.focus();
return (false);
}
';
}

} // fecha for da verificacao em js

echo '
return (true);
}
//-->
</script>

<form onsubmit="return valida_'.$_SESSION['form_name'].'(this)" name="'.$_SESSION['form_name'].'" action="?status=resultado" method="post">

'.$_SESSION['inicio'].'';

$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;

echo ''.$_SESSION['style1'].'';
if ( $campo[$indice]["obrigatorio"] == 'Sim' ) { echo '* ';}
echo ''.$campo[$indice]["titulo"].''.$_SESSION['style2'].'<input name="campo'.$indice.'" type="text" value="" size="'.$campo[$indice]["size"].'" maxlength="'.$campo[$indice]["maxlenght"].'" ';
 ##
if ( $campo[$indice]["tipo"] == 'Email' )
{ echo "
onBlur=VerificaEmail($_SESSION[form_name],'campo$indice')
"; }

if ( $campo[$indice]["tipo"] == 'CPF' )
{ echo "
onKeyPress=limita_numerico(event,false) onkeydown=FormataDadoCPF($_SESSION[form_name],'campo$indice',11,8,5,2,event) onBlur=VerificaSoCPF($_SESSION[form_name],'campo$indice')
"; }

if ( $campo[$indice]["tipo"] == 'CNPJ' )
{ echo "
OnKeyUp=\"FormataCGC($_SESSION[form_name], 'campo$indice', event);\" onKeyPress=limita_numerico(event,false) onBlur=dvCGC($_SESSION[form_name],'campo$indice')
"; }

if ( $campo[$indice]["tipo"] == 'N�meros' )
{ echo "
onKeypress=\"if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;\"
"; }

if ( $campo[$indice]["tipo"] == 'Valor' )
{ echo "
onKeyPress=limita_numerico(event,false) onkeydown=FormataValor($_SESSION[form_name], 'campo$indice',8,event,1)
"; }
##
echo ' />'.$_SESSION['style3'].'';

} // fecha for dos campos

echo ''.$_SESSION['fim'].'

<input name="Ir" type="submit" value="Avan�ar" />
</form>
Observa��o: Os campo com asterisco (*) s�o de preenchimento obrigat�rio.
';

?>
</body>
</html>
