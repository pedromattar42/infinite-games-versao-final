function VerificaSoCPF(pForm, pCampo)
{
   var wVr, wTam, wSoma, wSoma2, i, j, wDig1, wDig2,
   wVETOR_CC = new Array(9),
   wVETOR_PESO = new Array(9);

   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
          pCampo = i;
          i = pForm.elements.lenght;
      }
   }
   wVr = pForm[pCampo].value;
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( "-", "" );
   wTam = wVr.length + 1;

   if (wVr == '')
   {
      return false;
   }
   if (wTam < 11)
   {
      alert("Aten��o: N� de d�gitos do CPF menor que o normal.");
      pForm[pCampo].value = "";
      pForm[pCampo].focus();
      return false;
   }

   for (i = 0; i < wVr.length; i++)
   {
      if (isNaN(parseInt(wVr.charAt(i))) )
      {
         alert("Aten��o: O CPF cont�m d�gitos inv�lidos.");
         pForm[pCampo].value = "";
         pForm[pCampo].focus();
         return false;
      }
   }

   if (wVr == '00000000000' || wVr == '11111111111' || wVr == '22222222222' || wVr == '33333333333' || wVr == '44444444444' || wVr == '55555555555' ||
       wVr == '66666666666' || wVr == '77777777777' || wVr == '88888888888' || wVr == '99999999999')
   {
      alert("Aten��o: Este Tipo de CPF � inv�lido");
      pForm[pCampo].value = "";
      pForm[pCampo].focus();
      return false;
   }
   wSoma = 0;
   wSoma2 = 0;
   j = 2;
   for (i = 0; i < 11; i++)
   {
      wVETOR_CC[i] = wVr.charAt(i);
      wVETOR_PESO[i] = j;
      j++;
   }
   i = 0;
   while (i < 9)
   {
     i++;
     if (i < 10)
     {
        wSoma += wVETOR_CC[9 - i] * wVETOR_PESO[i - 1];
     }
        wSoma2 += wVETOR_CC[10 - i] * wVETOR_PESO[i - 1];
   }
   wDig1 = (wSoma * 10) % 11;
   wDig2 = (wSoma2 * 10) % 11;
   if (wDig1 == 10)
   {
      wDig1 = 0;
   }
   if (wDig2 == 10)
   {
      wDig2 = 0;
   }
   if (parseInt(wVr.charAt(9)) != wDig1 || parseInt(wVr.charAt(10)) != wDig2)
   {
      alert("Aten��o: CPF com D�gito verificador � inv�lido.");
      pForm[pCampo].value = "";
      pForm[pCampo].focus();
      return false;
   }
    return true;
}

function FormataDadoCPF(pForm,pCampo,pTamMax,pPos1,pPos2,pPosTraco,pTeclaPres)
{
   var wTecla, wVr, wTam;

   wTecla = pTeclaPres.keyCode;
   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
         pCampo = i;
         i = pForm.elements.lenght;
      }
   }
   wVr = pForm[pCampo].value;
   wVr = wVr.replace( "-", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( "/", "" );
   wTam = wVr.length ;
   if (wTam < pTamMax && wTecla != 8)
   {
      wTam = wVr.length + 1 ;
   }

   if (wTecla == 8 )
   {
      wTam = wTam - 1 ;
   }

   if ( wTecla == 8 || wTecla == 88 || wTecla >= 48 && wTecla <= 57 || wTecla >= 96 && wTecla <= 105 )
   {
      if ( wTam <= 2 )
      {
         pForm[pCampo].value = wVr ;
      }
      if (wTam > pPosTraco && wTam <= pTamMax)
      {
         wVr = wVr.substr(0, wTam - pPosTraco) + '-' + wVr.substr(wTam - pPosTraco, wTam);
      }
      if ( wTam == pTamMax)
      {
         wVr = wVr.substr( 0, wTam - pPos1 ) + '.' + wVr.substr(wTam - pPos1, 3) + '.' + wVr.substr(wTam - pPos2, wTam);
      }
      pForm[pCampo].value = wVr;

   }

}

function VerificaEmail(pform, pcampo)
{
   for (i=0; i < pform.elements.lenght; i++)
   {
      if (pform.elements[i].name == pcampo)
      {
          pcampo = i;
          i = pform.elements.lenght;
      }
   }

   parametro = pform[pcampo].value;
   teste_parametro = "false";
   tamanho_parametro = parametro.length;
   aposicao = 0; //posicao @
   pposicao = 0; //poiscao ponto
   narrobas = 0; // numero de @
   for (i = 0; i < tamanho_parametro; i++)
   {
      if (parametro.charAt(i) == "@")
      {
         narrobas = narrobas + 1
	 aposicao = i;
      }
      if (parametro.charAt(i) == ".")
      {
	 pposicao = i;
      }
   }
   if (aposicao > 0 && aposicao+1 < pposicao && narrobas<2)
   {
      teste_parametro = "true";
   }

   for (i = 0; i < tamanho_parametro; i++)
   {
      if (parametro.charAt(i) == " ")
      {
         teste_parametro = "false";
      }
   }

   if (tamanho_parametro < 5)
   {
       teste_parametro = "false"; /*tamanho minimo*/
   }


   if (parametro.charAt(0) == " " || parametro.charAt(1) == " ")
   {
      teste_parametro = "false";
   }

   if (teste_parametro == "false" && tamanho_parametro != 0 )
   {
       alert("Aten��o: E-mail inv�lido!");
       pform[pcampo].focus();
       return false;
   }
   else
   {
       return true;
   }
}

function FormataData(pForm, pCampo,pTeclaPres)
{
   var wTecla = pTeclaPres.keyCode;
   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
         pCampo = i;
         i = pForm.elements.lenght;
      }
   }

   wVr = pForm[pCampo].value;
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( "/", "" );
   wVr = wVr.replace( "/", "" );
   wTam = wVr.length + 1;

   if ( wTecla != 9 && wTecla != 8 )
   {
      if ( wTam > 2 && wTam < 5 )
         pForm[pCampo].value = wVr.substr( 0, wTam - 2  ) + '/' + wVr.substr( wTam - 2, wTam );

      if ( wTam > 5 && wTam <= 10 )
         pForm[pCampo].value = wVr.substr( 0, 2 ) + '/' + wVr.substr( 2, 2 ) + '/' + wVr.substr( 4, 4 );
   }
}

function VerificaData(pForm, pCampo, pDtProibida, maioratual)
{
   var wHoje = new Date();
   var wAUX, wAUX2, wDataValida;

   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
         pCampo = i;
         i = pForm.elements.lenght;
      }
   }
   wAUX2 = "";
   wAUX = pForm[pCampo].value;

   if (wAUX == "")
   {
      return false;
   }
   if (pDtProibida != "")
   {
      wAUX2 = pDtProibida;
      var wFrescuraSIAPI = new Date(wAUX2.substr(6, 4), wAUX2.substr(3,2) - 1, wAUX2.substr(0,2))
   }
   if (wAUX == "" || wAUX.length < 10)
   {
      alert("Aten��o:  Tamanho de data incorreto. Digite a data no formato DD/MM/AAAA.");
      pForm[pCampo].value = "";
      pForm[pCampo].focus();
      return false;
   }
   wDataValida = SbrebowsDataSdruxula(wAUX.substr(0,2),wAUX.substr(3,2), wAUX.substr(6, 4));
   if (!wDataValida)
   {
      alert("Aten��o: Data Inv�lida.");
      pForm[pCampo].value = "";
      pForm[pCampo].focus();
      return false;
   }
   else
   {
      var wDtRef = new Date(wAUX.substr(6, 4), wAUX.substr(3,2) - 1, wAUX.substr(0,2))
      if ((Date.parse(wDtRef) >= Date.parse(wHoje)) && (maioratual == 'N'))
      {
         alert("Aten��o: Data n�o pode ser maior que a data Atual.");
         pForm[pCampo].value = "";
         pForm[pCampo].focus();
         return false;
      }
      else
      {
         if (wAUX2 != "" && Date.parse(wDtRef) > Date.parse(wFrescuraSIAPI))
         {
             alert("Aten��o: Data n�o pode ser maior que " + pDtProibida + ". Redigite-a");
   	     pForm[pCampo].value = "";
             pForm[pCampo].focus();
	     return false;
         }
      }
   }
   return true;
}

































function FormataValor(pForm, pCampo, pTamMax, pTeclaPres, pVirgula)
{
   var wTecla = pTeclaPres.keyCode;

   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
          pCampo = i;
          i = pForm.elements.lenght;
      }
   }

   wVr = pForm[pCampo].value;
   wVr = wVr.replace( "/", "" );
   wVr = wVr.replace( "/", "" );
   wVr = wVr.replace( ",", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( "," , "" )
   wTam = wVr.length;

   if (wTam < pTamMax && wTecla != 8)
   {
      wTam = wVr.length + 1 ;
   }

   if (wTecla == 8 )
   {
      wTam = wTam - 1 ;
   }

   if ( wTecla == 8 || wTecla >= 48 && wTecla <= 57 || wTecla >= 96 && wTecla <= 105 )
   {
      if (pVirgula == 1)
      {
         if ( wTam <= 2 )
         {
            pForm[pCampo].value = wVr ;
         }
         if ( (wTam > 2) && (wTam <= 5) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 2 ) + ',' + wVr.substr( wTam - 2, wTam ) ;
         }
         if ( (wTam >= 6) && (wTam <= 8) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 5 ) + '.' + wVr.substr( wTam - 5, 3 ) + ',' + wVr.substr( wTam - 2, wTam ) ;
         }
         if ( (wTam >= 9) && (wTam <= 11) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 8 ) + '.' + wVr.substr( wTam - 8, 3 ) + '.' + wVr.substr( wTam - 5, 3 ) + ',' + wVr.substr( wTam - 2, wTam ) ;
         }
         if ( (wTam >= 12) && (wTam <= 14) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 11 ) + '.' + wVr.substr( wTam - 11, 3 ) + '.' + wVr.substr( wTam - 8, 3 ) + '.' + wVr.substr( wTam - 5, 3 ) + ',' + wVr.substr( wTam - 2, wTam ) ;
         }
         if ( (wTam >= 15) && (wTam <= 17) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 14 ) + '.' + wVr.substr( wTam - 14, 3 ) + '.' + wVr.substr( wTam - 11, 3 ) + '.' + wVr.substr( wTam - 8, 3 ) + '.' + wVr.substr( wTam - 5, 3 ) + ',' + wVr.substr( wTam - 2, wTam ) ;
         }
      }
      else if (pVirgula == 2)
      {
         if ( wTam <= 3 )
         {
            pForm[pCampo].value = wVr ;
         }
         if ( (wTam > 3) && (wTam <= 6) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 3 ) + ',' + wVr.substr( wTam - 3, wTam ) ;
         }
         if ( (wTam >= 7) && (wTam <= 9) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 6 ) + '.' + wVr.substr( wTam - 6, 3 ) + ',' + wVr.substr( wTam - 3, wTam ) ;
         }
         if ( (wTam >= 10) && (wTam <= 12) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 9 ) + '.' + wVr.substr( wTam - 9, 3 ) + '.' + wVr.substr( wTam - 5, 3 ) + ',' + wVr.substr( wTam - 3, wTam ) ;
         }
         if ( (wTam >= 13) && (wTam <= 15) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 12 ) + '.' + wVr.substr( wTam - 12, 3 ) + '.' + wVr.substr( wTam - 9, 3 ) + '.' + wVr.substr( wTam - 6, 3 ) + ',' + wVr.substr( wTam - 3, wTam ) ;
         }
         if ( (wTam >= 16) && (wTam <= 18) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 15 ) + '.' + wVr.substr( wTam - 15, 3 ) + '.' + wVr.substr( wTam - 12, 3 ) + '.' + wVr.substr( wTam - 9, 3 ) + '.' + wVr.substr( wTam - 6, 3 ) + ',' + wVr.substr( wTam - 3, wTam ) ;
         }
      }
      else
      {
         if ( wTam <= 3 )
         {
            pForm[pCampo].value = wVr ;
         }
         if ( (wTam > 3) && (wTam <= 6) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 3 ) + '.' + wVr.substr( wTam - 3, wTam ) ;
         }
         if ( (wTam >= 7) && (wTam <= 9) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 6 ) + '.' + wVr.substr( wTam - 6, 3 ) + '.' + wVr.substr( wTam - 3, wTam ) ;
         }
         if ( (wTam >= 10) && (wTam <= 12) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 9 ) + '.' + wVr.substr( wTam - 9, 3 ) + '.' + wVr.substr( wTam - 6, 3 ) + '.' + wVr.substr( wTam - 3, wTam ) ;
         }
         if ( (wTam >= 13) && (wTam <= 15) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 12 ) + '.' + wVr.substr( wTam - 12, 3 ) + '.' + wVr.substr( wTam - 9, 3 ) + '.' + wVr.substr( wTam - 6, 3 ) + '.' + wVr.substr( wTam - 3, wTam ) ;
         }
         if ( (wTam >= 16) && (wTam <= 18) )
         {
            pForm[pCampo].value = wVr.substr( 0, wTam - 15 ) + '.' + wVr.substr( wTam - 15, 3 ) + '.' + wVr.substr( wTam - 12, 3 ) + '.' + wVr.substr( wTam - 9, 3 ) + '.' + wVr.substr( wTam - 6, 3 ) + '.' + wVr.substr( wTam - 3, wTam ) ;
         }
      }
   }


}

function LimiteValor(pForm, pCampo, ValorMaximo, Mensagem)
{
   var Valor;

   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
          pCampo = i;
          i = pForm.elements.lenght;
      }
   }

   if (pForm[pCampo].value != "")
   {
      Valor = pForm[pCampo].value;
      Valor = Valor.replace( ".", "" );
      Valor = Valor.replace( ".", "" );
      Valor = Valor.replace( ",", "." );
      Valor = parseFloat(Valor);

      ValorMaximo = ValorMaximo.replace( ".", "" );
      ValorMaximo = ValorMaximo.replace( ".", "" );
      ValorMaximo = ValorMaximo.replace( ",", "." );
      ValorMaximo = parseFloat(ValorMaximo);

      if (Valor > ValorMaximo)
      {
         alert(Mensagem);
         pForm[pCampo].focus();
         pForm[pCampo].value = "";
         return false;
      }
      else
      {
         return true;
      }

   }
}




function VerificaCampoVazio(pForm, pCampo)
{
   var i, wResult;
   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
          pCampo = i;
          i = pForm.elements.lenght;
      }
   }

   wResult = true;
   if (pForm[pCampo].value == "")
   {
      alert("Campo n�o pode ser vazio !!!");
      pForm[pCampo].focus();
      wResult = false;

   }
   return wResult;
}





function Formatacep(pForm, pCampo, pTeclaPres)
{
   var wTecla = pTeclaPres.keyCode;
   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
         pCampo = i;
         i = pForm.elements.lenght;
      }
   }
   var wTam;
   wVr = pForm[pCampo].value;
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( "-", "" );
   wVr = wVr.replace( "/", "" );
   wTam = wVr.length + 1;
   if ( wTecla != 9 && wTecla != 8 )
   {
      if ( wTam > 2 && wTam < 6 )
      {
         pForm[pCampo].value = wVr.substr( 0, wTam - 2  ) + '.' + wVr.substr( wTam - 2, wTam );
      }
      if ( wTam > 6 && wTam <= 8 )
      {
         pForm[pCampo].value = wVr.substr( 0, 2 ) + '.' + wVr.substr( 2, 3 ) + '-' + wVr.substr( 5, 3 );
      }
   }
}



function dvCGC(pForm, pCampo)
{
   var Numero = pForm[pCampo].value.substr(0, 15);
   var Digito = pForm[pCampo].value.substr(16, 2);
   var CNPJ = pForm[pCampo].value

   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
         pCampo = i;
         i = pForm.elements.lenght;
      }
   }

   Numero = Numero.replace(".","");
   Numero = Numero.replace(".","");
   Numero = Numero.replace("/","");
   Numero = Numero.replace("-","");

   CNPJ = CNPJ.replace(".","");
   CNPJ = CNPJ.replace(".","");
   CNPJ = CNPJ.replace("/","");
   CNPJ = CNPJ.replace("-","");

   var CGC = Numero;
   var peso1 = '543298765432';
   var peso2 = '654329876543';
   var soma1 = 0;
   var soma2 = 0;
   var digito1 = 0;
   var digito2 = 0;

   if (CNPJ == '00000000000000')
   {
      alert("CNPJ Inv�lido. Redigite!");
      pForm[pCampo].value = "";
      pForm[pCampo].focus();
      return false;
   }

   if ((Numero.length + Digito.length + 1 > 1) && (Numero.length + Digito.length + 1 < 15))
   {
      alert("N� de d�gitos do CNPJ menor que o normal. Redigite !!!");
      pForm[pCampo].value = "";
      pForm[pCampo].focus();
      return false;
   }

   if (Numero.length + Digito.length + 1 > 1)
   {
      for (i = 1; i < 12 - Numero.length + 1; i++)
      {
         CGC = eval("'" + 0 + CGC + "'")
      }

      for (i = 1; i < CGC.length+1; i++)
      {
         soma1 += CGC.substring(i, i-1) * peso1.substring(i, i-1);
      }

      soma1 %= 11;

      if (soma1  < 2)
      {
         digito1 = 0;
      }
      else
      {
         digito1 = 11 - soma1;
      }

      for (i = 1; i < CGC.length+1; i++)
      {
         soma2 += CGC.substring(i, i-1) * peso2.substring(i, i-1);
      }

      soma2 += digito1 * 2
      soma2 %= 11;

      if (soma2  < 2)
      {
         digito2 = 0;
      }
      else
      {
         digito2 = 11 - soma2;
      }

      if (eval("'" + digito1 + digito2 + "'") != Digito)
      {
          alert("CNPJ inv�lido. Redigite !!!");
	  pForm[pCampo].value = "";
	  pForm[pCampo].focus();
	  return false;
      }
      else
      {
	  return true;
      }
   }
}


function FormataDadoCGC(pForm,pCampo,pTeclaPres)
{
   var wTecla, wVr, wTam;

   wTecla = pTeclaPres.keyCode;

   for (i=0; i < pForm.elements.lenght; i++)
   {
      if (pForm.elements[i].name == pCampo)
      {
         pCampo = i;
         i = pForm.elements.lenght;
      }
   }
   wVr = pForm[pCampo].value;
   wVr = wVr.replace( "-", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( ".", "" );
   wVr = wVr.replace( "/", "" );
   wTam = wVr.length ;

   if (wTam < 14 && wTecla != 8)
   {
      wTam = wVr.length + 1 ;
   }

   if (wTecla == 8 )
   {
      wTam = wTam - 1 ;
   }

   if ( wTecla == 8 || wTecla == 88 || wTecla >= 48 && wTecla <= 57 || wTecla >= 96 && wTecla <= 105 )
   {
      if ( wTam <= 2 )
      {
         pForm[pCampo].value = wVr ;
      }
      if (wTam > 2 && wTam <= 14)
      {
         wVr = wVr.substr(0, wTam - 2) + '-' + wVr.substr(wTam - 2, wTam);
      }

      if ( wTam == 14)
      {
         wVr = wVr.substr( 0, wTam - 12 ) + '.' + wVr.substr(wTam - 12, 3) + '.' + wVr.substr(wTam - 9, 3) + "/" + wVr.substr(wTam - 6, wTam);
      }
      pForm[pCampo].value = wVr;

   }
}


function SbrebowsDataSdruxula(pDia, pMes, pAno)
{
  var v_dia, v_mes, v_ano;

  v_dia = pDia;
  v_mes = pMes;
  v_ano = pAno;

  if (((v_ano < 1900) || (v_ano > 2079)) && (v_ano.length != 0))
  {
     return(false);
  }
  if (v_dia > 31)
  {
     return(false);
  }
  if (v_mes > 12) {
	return(false);
  }
  if (v_dia == "31")
  {
     if ((v_mes == "04") || (v_mes == "06") || (v_mes == "09") || (v_mes == "11"))
     {
        return(false);
     }
  }
  if (v_mes == "02")
  {
     if (!(v_ano%4))
     {
        if (v_dia > 29)
        {
           return(false);
        }
     }
     else if (v_dia > 28)
     {
        return(false);
     }
  }


  if (((v_dia != "") || (v_mes != "") || (v_ano != "")) && ((v_dia == "") || (v_mes == "") || (v_ano == "")))
  {
     return(false);
  }

  return(true);
}


function limita_numerico(e,virgula_ponto)
{
	if (document.all) // Internet Explorer
		var tecla = event.keyCode;
	else if(document.layers) // Nestcape
		var tecla = e.which;

    if (tecla > 47 && tecla < 58)  // numeros de 0 a 9
		return true;
	else
	{
	   if (virgula_ponto)
	   {
          if  ((tecla == 44) || (tecla == 46))
	         return true;
	   }

       if (tecla != 8) // backspace
       {
		  event.keyCode = 0;
//		  return false;
       }
	   else
		  return true;
	}
}
