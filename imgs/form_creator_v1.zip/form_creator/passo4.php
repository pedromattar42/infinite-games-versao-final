<?

session_start();

@ $campo = $_SESSION['campo'];

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: MaCaFe Webdeveloper :: Gerador de Formul�rio ::</title>

<link href="estilos/estilos.css" rel="stylesheet" type="text/css" />

</head>

<body>

<table width="560" height="20" cellpadding="0" cellspacing="0" border="1" bordercolor="#cccccc" bgcolor="#F4F4F4">
 <tr>
    <td bgcolor="#CCCCCC" align="left">
    &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Resultado avan�ado</b></font>
    </td>
 </tr> 
 <tr>
    <td align="left">
	<table width="560">
<tr>
  <td align="center">
		  <textarea name="style1" style="width: 540px;" rows="26" readonly="readonly"><?
echo '<!--
Formul�rio com valida��o em JavaScript e PHP Gerado por MaCaFe Script Creator
Todos direitos intelectuais de cria��o e desenvolvimento para Felipe Cardoso Martins
Email: felipe@eletronicparty.com - Site oficial: www.eletronicparty.com/felipe
-->

<script language="javascript" src=\'classes/classes_js.js\'></script>

<?
error_reporting(E_ALL);
require (\'classes/classes_php.php\');

if ( isset($_GET["status"]) ) {
$status = $_GET["status"];
}
else {
$status = NULL;
}

if ( $status == \'resultado\' ) {

';
$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;
echo '$campo'.$indice.' = $_POST["campo'.$indice.'"];
';
}

echo '
$erro = 0 ;
';
$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;

if ( $campo[$indice]["obrigatorio"] == 'Sim' ) {
echo '
if ( empty($campo'.$indice.') ){
echo \'Aten��o: O campo '.$campo[$indice]["titulo"].' deve ser preenchido.<br />\';
$erro ++;
}
';
}

if ( ( $campo[$indice]["tam_min"] != '' ) or ( !empty($campo[$indice]["tam_min"]) ) ) {
echo '
if ( ( strlen($campo'.$indice.') < '.$campo[$indice]["tam_min"].' ) and ( !empty($campo'.$indice.') ) ){
echo \'Aten��o: O campo '.$campo[$indice]["titulo"].' deve ter no m�nimo '.$campo[$indice]["tam_min"].' caracteres.<br />\';
$erro ++;
}
';
}

if ( ( $campo[$indice]["tam_max"] != '' ) or ( !empty($campo[$indice]["tam_max"]) ) ) {
echo '
if ( ( strlen($campo'.$indice.') > '.$campo[$indice]["tam_max"].' ) and ( !empty($campo'.$indice.') ) ){
echo \'Aten��o: O campo '.$campo[$indice]["titulo"].' deve ter no m�ximo '.$campo[$indice]["tam_max"].' caracteres.<br />\';
$erro ++;
}
';
}

if ( ( $campo[$indice]["tipo"] == 'CPF' )  ) {
echo '
if ( !empty ($campo'.$indice.') ) {
 $oCpf = new cpf;
 if ($oCpf->verifica_cpf($campo'.$indice.')){
 # Passo com sucesso o cpf
 }
 else{
 echo "Aten��o: O '.$campo[$indice]["titulo"].' ( $campo'.$indice.' ) &eacute; inv&aacute;lido.<BR>";
 $erro ++;
 }
}
';
}

if ( ( $campo[$indice]["tipo"] == 'Email' )  ) {
echo '
if ( !empty ($campo'.$indice.') ) {
  if (verifica_email($campo'.$indice.')){
# Passo com sucesso o email
 }
 else{
 echo "Aten��o: O '.$campo[$indice]["titulo"].' ( $campo'.$indice.' ) &eacute; inv&aacute;lido.<BR>";
 $erro ++;
 }
}
';
}

if ( ( $campo[$indice]["tipo"] == 'CNPJ' )  ) {
echo '
if ( !empty ($campo'.$indice.') ) {
$cnpj= $campo'.$indice.';
$oCnpj = new cnpj;
if ($oCnpj->verfica_cnpj($cnpj)==1){
# Passo com sucesso o cnpj
}
else{
echo "Aten��o: O '.$campo[$indice]["titulo"].' ( $campo'.$indice.' ) &eacute; inv&aacute;lido.<BR>";
$erro ++;
 }
}

';
}

}
echo '
if ( $erro != 0 ) {
echo \'<a href="javascript:history.go(-1);" title="Voltar">Voltar</a>\';
}

else {
';

$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;
echo 'echo "'.$campo[$indice]["titulo"].' = $campo'.$indice.' <br />";
';
}

echo '
/*
As variaveis envolvidas no formul�rio
foram todas resgatadas da maneira
correta e est�o pronta para uso da maneira
que lhe for melhor.
Pode ser feita uma associa��o dos
valores para facilitar o c�digo,
abaixo segue a associa��o com o t�tulo
 da mesma.
 
';
$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;
echo ''.$campo[$indice]["titulo"].' = $campo'.$indice.';
';
}
echo '
Exemplo de como voc� pode associar:

$nome = $campo0;
$cnpj = $campo1;
$endereco = $campo2;

Desta forma  ficar� muito mais f�cil de trabalhar evitando confus�es
*/

}
}

echo "
<script language=\"javascript\">

<!--
function valida_'.$_SESSION['form_name'].'('.$_SESSION['form_name'].'){
';

$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) {
$indice = $chave_cesta[$i] ;

if ( $campo[$indice]["obrigatorio"] == 'Sim' ) {
echo '
if ('.$_SESSION['form_name'].'.campo'.$indice.'.value == \"\"){
alert(\"Aten��o: O campo '.$campo[$indice]["titulo"].' deve ser preenchido\");
'.$_SESSION['form_name'].'.campo'.$indice.'.focus();
return (false);
}
';
}

if ( ( $campo[$indice]["tam_min"] != '' ) or ( !empty($campo[$indice]["tam_min"]) ) ) {
echo '
if ('.$_SESSION['form_name'].'.campo'.$indice.'.value.length < '.$campo[$indice]["tam_min"].' ){
alert(\"Aten��o: O campo '.$campo[$indice]["titulo"].' deve ter no m�nimo '.$campo[$indice]["tam_min"].' caracteres\");
'.$_SESSION['form_name'].'.campo'.$indice.'.focus();
return (false);
}
';
}

if ( ( $campo[$indice]["tam_max"] != '' ) or ( !empty($campo[$indice]["tam_max"]) ) ) {
echo '
if ('.$_SESSION['form_name'].'.campo'.$indice.'.value.length > '.$campo[$indice]["tam_max"].' ){
alert(\"Aten��o: O campo '.$campo[$indice]["titulo"].' deve ter no m�ximo '.$campo[$indice]["tam_max"].' caracteres\");
'.$_SESSION['form_name'].'.campo'.$indice.'.focus();
return (false);
}
';
}

}

echo '
return (true);
}
//-->

</script>
";

echo \'
<form onsubmit="return valida_'.$_SESSION['form_name'].'(this)" name="'.$_SESSION['form_name'].'" action="?status=resultado" method="post">

'.$_SESSION['inicio'].'';
$chave_cesta  =  @array_keys($_SESSION['campo']);
for($i=0; $i<sizeof($chave_cesta); $i++) { 
$indice = $chave_cesta[$i] ;
echo ''.$_SESSION['style1'].'';
if ( $campo[$indice]["obrigatorio"] == 'Sim' ) { echo '* ';}
echo ''.$campo[$indice]["titulo"].''.$_SESSION['style2'].'<input name="campo'.$indice.'" type="text" value="" size="'.$campo[$indice]["size"].'" maxlength="'.$campo[$indice]["maxlenght"].'" ';
 ##
 ####
 #####
if ( $campo[$indice]["tipo"] == 'Email' )
{ echo "
onBlur=VerificaEmail($_SESSION[form_name],\'campo$indice\')
"; }

if ( $campo[$indice]["tipo"] == 'CPF' )
{ echo "
onKeyPress=limita_numerico(event,false) onkeydown=FormataDadoCPF($_SESSION[form_name],\'campo$indice\',11,8,5,2,event) onBlur=VerificaSoCPF($_SESSION[form_name],\'campo$indice\')
"; }

if ( $campo[$indice]["tipo"] == 'CNPJ' )
{ echo "
OnKeyUp=\"FormataCGC($_SESSION[form_name], \'campo$indice\', event);\" onKeyPress=limita_numerico(event,false) onBlur=dvCGC($_SESSION[form_name],\'campo$indice\')
"; }

if ( $campo[$indice]["tipo"] == 'N�meros' )
{ echo "
onKeypress=\"if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;\"
"; }

if ( $campo[$indice]["tipo"] == 'Valor' )
{ echo "
onKeyPress=limita_numerico(event,false) onkeydown=FormataValor($_SESSION[form_name], \'campo$indice\',8,event,1)
"; }

 #####
 ####
 ##
echo ' />'.$_SESSION['style3'].'';
}
echo ''.$_SESSION['fim'].'

<input name="Ir" type="submit" value="Avan�ar" />
</form>
Observa��o: Os campo com asterisco (*) s�o de preenchimento obrigat�rio.
\';
?>';
?>
</textarea>
		   </td>
</tr> 
       </table>
	      <table>
         <tr>
         <td align="center" width="550">
         <BR />
         <button onClick="javascript:window.location.href='passo3.php'"><< Anterior</button><BR />
<BR />
<input name="Ver" type="button" id="button" value="Ver script em funcionamento" onclick="window.open('exemplo.php', 'exemplo', 'width=650,height=550,scrollbars=yes');" >
&nbsp;<button onClick="javascript:window.location.href='reinicia_aplicacao.php'">Reiniciar aplica��o</button>
		 </td>
         </tr>
                  </table>
	</td>
 </tr> 
</table>

</body>
</html>
