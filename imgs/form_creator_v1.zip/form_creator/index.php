<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: MaCaFe Webdeveloper :: Gerador de Formul�rio ::</title>

<link href="estilos/estilos.css" rel="stylesheet" type="text/css" />

</head>

<body>

<table width="560" height="20" cellpadding="0" cellspacing="0" border="1" bordercolor="#cccccc" bgcolor="#F4F4F4">
 <tr>
    <td bgcolor="#CCCCCC" align="left">
    &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Instru��es</b></font>
    </td>
 </tr> 
 <tr>
    <td align="left">
	<table width="560">
	  <tr>
        <td>
	&nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp; 1&ordm; passo: Dados iniciais ( Configura&ccedil;&otilde;es )<br />
  &nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp; 2&ordm; passo: Determinando campos<br />
  &nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp; 3&ordm; passo: Resultado comentado<br />
  &nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp; 3&ordm; passo: Resultado avan�ado<br />
<p align="center">
<input type="submit" name"Proximo" value="Pr�ximo >>" onClick="javascript:window.location.href='passo1.php'"><BR />
<BR />
<button onClick="javascript:window.location.href='reinicia_aplicacao.php'">Reiniciar aplica��o</button>
</p>
	 </td>
           </tr> 
       </table>
	</td>
 </tr> 
</table>

</body>
</html>
