<?

session_start();

@ $status = $_GET["status"];

if ( $status == 'resultado' ) {
$name_form = $_POST["name_form"];
$style1 = $_POST["style1"];
$style2 = $_POST["style2"];
$style3 = $_POST["style3"];
$inicio = $_POST["inicio"];
$fim = $_POST["fim"];

session_unregister("form_name");
session_unregister("style1");
session_unregister("style2");
session_unregister("style3");
session_unregister("inicio");
session_unregister("fim");

$_SESSION['form_name'] = $name_form;
$_SESSION['style1'] = $style1;
$_SESSION['style2'] = $style2;
$_SESSION['style3'] = $style3;
$_SESSION['inicio'] = $inicio;
$_SESSION['fim'] = $fim;

}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: MaCaFe Webdeveloper :: Gerador de Formul�rio ::</title>

<link href="estilos/estilos.css" rel="stylesheet" type="text/css" />

<script language="javascript">

<!--
function checa_form(form){

if (form.name_form.value == ""){
alert("Aten��o: O campo Nome do formul�rio deve ser preenchido");
form.name_form.focus();
return (false);
}

return (true);
}
//-->

</script>

</head>

<body>

<?

@ $status = $_GET["status"];

if ( $status == 'resultado' ) {

echo '
<table width="560" height="20" cellpadding="0" cellspacing="0" border="1" bordercolor="#cccccc" bgcolor="#F4F4F4">
 <tr>
    <td bgcolor="#CCCCCC" align="left">
    &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Resultado</b></font>
    </td>
 </tr> 
 <tr>
    <td align="left">
	<table>
	  <tr>
        <td>
	';

$erro = 0;

if ( empty($name_form) ) {
echo '&nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp; Aten��o: O campo Nome do formul�rio deve ser preenchido<br />';
$erro ++;
}

if ( $erro != 0 ) {
echo '&nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp; <a href="javascript:history.go(-1);" title="Voltar">Voltar</a><br />';
}

else {
echo '
&nbsp;&nbsp;<img src="imagens/seta4.gif" >&nbsp; Passo 1 realizado com sucesso.<br />
<script language="JavaScript">
window.location="passo2.php";
</script>
';
}
	
	echo '
		     </td>
           </tr> 
       </table>
	</td>
 </tr> 
</table>
<br />
';

}

?>

<table width="560" height="20" cellpadding="0" cellspacing="0" border="1" bordercolor="#cccccc" bgcolor="#F4F4F4">
 <tr>
    <td bgcolor="#CCCCCC" align="left">
    &nbsp;&nbsp;<img src="imagens/seta1.gif" >&nbsp;<font size="2"><b>Dados iniciais ( Configura��es )</b></font>
    </td>
 </tr> 
 <tr>
     <td align="left">
	 <form onsubmit="return checa_form(this)" name="form" action="?status=resultado" method="post">
	 <table>
        <tr>
           <td>
		   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Nome do formul�rio:&nbsp;
		   </td>
		   <td>
		   <input name="name_form" type="text" value="<? if ( isset( $_SESSION['form_name'] ) ) { echo $_SESSION['form_name']; } ?>" size="50" maxlength="100" />
		   </td>
        </tr>
        <tr>
           <td>
		   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Estilo - �nicio:&nbsp;
		   </td>
		   <td>
		   <textarea name="inicio" style="width: 317px;" cols="25" rows="2"><? if ( isset( $_SESSION['inicio'] ) ) { echo $_SESSION['inicio']; } ?></textarea>
		   </td>
        </tr>
        <tr>
           <td>
		   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Estilo - 1&ordf; parte:&nbsp;
		   </td>
		   <td>
		   <textarea name="style1" style="width: 317px;" cols="25" rows="2"><? if ( isset( $_SESSION['style1'] ) ) { echo $_SESSION['style1']; } ?></textarea>
		   </td>
        </tr>
        <tr>
           <td>
		   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Estilo - 2 &ordf; parte:</td>
		   <td>
		   <textarea name="style2" style="width: 317px;" cols="25" rows="2"><? if ( isset( $_SESSION['style2'] ) ) { echo $_SESSION['style2']; } ?></textarea
		   ></td>
        </tr>
        <tr>
           <td>
		   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Estilo - 3 &ordf; parte:</td>
		   <td>
		   <textarea name="style3" style="width: 317px;" cols="25" rows="2"><? if ( isset( $_SESSION['style3'] ) ) { echo $_SESSION['style3']; } ?></textarea
		   ></td>
        </tr>
        <tr>
           <td>
		   &nbsp;<img src="imagens/seta7.gif" >&nbsp;Estilo - Fim:&nbsp;
		   </td>
		   <td>
		   <textarea name="fim" style="width: 317px;" cols="25" rows="2"><? if ( isset( $_SESSION['fim'] ) ) { echo $_SESSION['fim']; } ?></textarea>
		   </td>
        </tr>
     </table>
	 <table>
	 <tr>
	 <td align="center" width="550">
	 <button onClick="javascript:window.location.href='index.php'"><< Anterior</button>&nbsp;<input name="Pr�ximo" type="submit" value="Pr�ximo >>" />
	 </td>
	 </tr>
	 </form>
	 </table>	 
     </td>
 </tr>
</table>

</body>
</html>
